#!/usr/bin/env bash
# Simple local deploy: build the image and (re)start the stack.
set -euo pipefail

echo "Building image..."
docker build -t devops-cicd-pipeline:latest .

echo "Starting stack..."
docker compose up -d --build

echo "Waiting for the app..."
for i in {1..15}; do
  if curl -fs http://localhost:5000/health >/dev/null; then
    echo "App is healthy: http://localhost:5000"
    exit 0
  fi
  sleep 2
done

echo "App failed health check" >&2
exit 1
