"""Small Flask service used to demonstrate a full DevOps pipeline."""
import os
import time

from flask import Flask, jsonify, request, Response
from prometheus_client import (CONTENT_TYPE_LATEST, Counter, Histogram,
                               generate_latest)

app = Flask(__name__)
START_TIME = time.time()
VERSION = os.getenv("APP_VERSION", "1.0.0")

REQUESTS = Counter("http_requests_total", "Total HTTP requests",
                   ["method", "endpoint", "status"])
LATENCY = Histogram("http_request_duration_seconds", "Request latency",
                    ["endpoint"])


@app.before_request
def _start_timer():
    request._start = time.time()


@app.after_request
def _record_metrics(response):
    endpoint = request.path
    LATENCY.labels(endpoint).observe(time.time() - getattr(request, "_start", time.time()))
    REQUESTS.labels(request.method, endpoint, response.status_code).inc()
    return response


@app.get("/")
def index():
    return jsonify(message="Hello from the DevOps pipeline!", version=VERSION)


@app.get("/health")
def health():
    return jsonify(status="ok", uptime_seconds=round(time.time() - START_TIME, 2))


@app.get("/metrics")
def metrics():
    return Response(generate_latest(), mimetype=CONTENT_TYPE_LATEST)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", 5000)))
