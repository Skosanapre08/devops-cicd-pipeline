import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "app"))

from main import app  # noqa: E402


def client():
    return app.test_client()


def test_index():
    r = client().get("/")
    assert r.status_code == 200
    assert "message" in r.get_json()


def test_health():
    r = client().get("/health")
    assert r.status_code == 200
    assert r.get_json()["status"] == "ok"


def test_metrics():
    client().get("/")
    r = client().get("/metrics")
    assert r.status_code == 200
    assert b"http_requests_total" in r.data
