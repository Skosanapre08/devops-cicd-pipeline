# Runs the app container locally through the Docker provider.
# Swap this for an AWS/Azure/GCP provider when you are ready for the cloud.
terraform {
  required_providers {
    docker = {
      source  = "kreuzwerker/docker"
      version = "~> 3.0"
    }
  }
}

provider "docker" {}

variable "image" {
  type    = string
  default = "devops-cicd-pipeline:latest"
}

variable "external_port" {
  type    = number
  default = 5000
}

resource "docker_container" "app" {
  name  = "devops-app"
  image = var.image

  ports {
    internal = 5000
    external = var.external_port
  }
}

output "app_url" {
  value = "http://localhost:${var.external_port}"
}
